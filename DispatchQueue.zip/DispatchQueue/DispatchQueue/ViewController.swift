//
//  ViewController.swift
//  DispatchQueue
//
//  Created by limyunhwi on 2021/10/10.
//

//스레드에 따른 작동 여부 확인 예제
import UIKit

class ViewController: UIViewController {

    @IBOutlet var timerLable: UILabel!
    @IBOutlet var finishLable: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //0.1초마다 제공되는 값을 갱신하겠다.
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) {
            timer in
             //1970년 이후 계속 진행되는 시간은 숫자로 제공
            //description: 해당되는 내용은 string으로 제공
            self.timerLable.text = Date().timeIntervalSince1970.description
        }
    }


    @IBAction func action1(_ sender: UIButton) {
        simpleClosure {
            //메인스레드에서 실행
            //UI는 메인 스레드에서 구현되어야 한다.
            DispatchQueue.main.async {
                self.finishLable.text = "끝"
            }
        }
    }
    
    
    //클로져를 사용하여 메인이 아닌 다른 스레드에서 실행되는 코드 구현해보자
    func simpleClosure(completion: @escaping () -> Void) {
        
        //메인 스레드가 아닌 다른 스레드에서 실행
        DispatchQueue.global().async {
            for index in 0..<10 {
                Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
                print(index)
            }
            completion() //호출
            //실행하는 바디는 사용하는 곳에 구현한다.
        }
        //메인 스레드를 멈추면 모든 라이프 사이클관 관련있는 메인 스레드이기 때문에 스크롤, 화면 등이 아예 멈춘다. 따라서 사용자에게 오류가 있는 것처럼 보여진다.
        //화면이 실행되더라도 내가 다른 작업을 할 수 있어야함 -> 메인 스레드 외의 다른 스레드를 만든다. 작업자를 더 데려온다.
    }
    @IBAction func action2(_ sender: UIButton) {
        let dispatchGroup = DispatchGroup()
        //DispatchGroup은 작업이 끝나지 않았는데 완료 시 실행되는 코드가 실행되지 않도록 작업 여부를 수동으로 설정할 수 있는 기능이 있다.
        
        //queue1이라는 새로운 스레드 생성
        let queue1 = DispatchQueue(label: "q1") //커스텀하게 만들어서 사용한다.
        let queue2 = DispatchQueue(label: "q2")
        let queue3 = DispatchQueue(label: "q3")
        
        //async는 시작은 하지만 끝내는건 알아서 한다.
        //기본적으로 로직은 순서대로 시작과 완료를 하지만, async는 완료를 하지 않아도 다음 로직을 시작한다.
        //하지만 하나의 작업자(스레드)에 일을 부여하면 sync처럼 로직 순서대로 작업을 수행한다.
        queue1.async(group: dispatchGroup, qos: .background){//qos는 우선순위를 넣을 때 사용한다. background는 가장 우선순위가 낮다.
            //작업 여부를 수동으로 설정, enter: 작업 중인게 하나 있다.
            dispatchGroup.enter()
            
            //스레드 안에 스레드 생성할 수 있다
            //작업자가 한 명 더 생겨난 것이므로 queue1은 이 작업자에게 일을 맡기고 다음으로 넘어간다. 해당 작업자의 일이 끝나는것은 신경쓰지 않는다.
            //이 일이 끝나기 전에 다음으로 넘어간다.
            DispatchQueue.global().async {
                for index in 0..<10 {
                    Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
                    print(index)
                }
                //작업이 끝났다.
                dispatchGroup.leave()
            }
        }
//        queue1.async(group: dispatchGroup){
//            for index in 10..<20 {
//                Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
//                print(index)
//            }
//        }
//        queue1.async(group: dispatchGroup){
//            for index in 20..<30 {
//                Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
//                print(index)
//            }
//        }
        
        //스레드 queue1,2,3 모두 각자 알아서 실행. 여러 명의 작업자가 자신에게 부여된 일을 알아서 각자 수행
        queue2.async(group: dispatchGroup, qos: .userInteractive){// userInteractive- 가장 높은 우선순위, 바로 사용자와 상호작용해야하는 것
            dispatchGroup.enter()
            
            DispatchQueue.global().async { //global - 백그라운드
                for index in 10..<20 {
                    Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
                    print(index)
                }
                dispatchGroup.leave()
            }
        }
        queue3.async(group: dispatchGroup){
            dispatchGroup.enter()
            
            DispatchQueue.global().async {
                for index in 20..<30 {
                    Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
                    print(index)
                }
                dispatchGroup.leave()
            }
        }
    
        //queue 1, 2, 3이 끝났을 때 (group의 스레드가 모두 끝났을 때)수행하는 코드 작성
        dispatchGroup.notify(queue: DispatchQueue.main){
            print("끝")
            //queue가 작업자(스레드)에게 일을 맡기고 다음으로, 즉 끝내버린다.
            //따라서 스레드가 모두 끝났을 때 수행하는 코드가 작업이 끝나기도 전에 실행된다.
        }
    }
    
    
    @IBAction func action3(_ sender: UIButton) {
        let queue1 = DispatchQueue(label: "q1")
        let queue2 = DispatchQueue(label: "q2")
        
        //sync는 다른 스레드를 다 멈춰버리고 내 작업을 진행한다. 내 작업이 끝나야 다른 스레드 작업 진행 가능
        //내 작업이 끝날 때까지 다른 스레드 작업 못한다. lock이 걸린다.
        queue1.sync(){
            for index in 0..<10 {
                Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
                print(index)
            }
        }
        
        queue2.sync(){
            for index in 10..<20 {
                Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
                print(index)
            }
        }
        
        
        //deadlock -> 상대 작업이 끝날 때까지 서로 계속 기다리는 상태
        //같은 스레드라서 서로 작업이 끝나지 않은 상태여서 서로를 기다리고 있음
        //sync는 작업이 끝날 때까지 스레드를 잡고 기다리고만 있어서 크래쉬가 발생하여 작업이 죽어버린다.
//        queue1.sync(){
//            for index in 0..<10 {
//                Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
//                print(index)
//            }
//            queue1.sync(){
//                for index in 0..<10 {
//                    Thread.sleep(forTimeInterval: 0.2) //메인스레드가 0.2초씩 멈췄다가 시작
//                    print(index)
//                }
//            }
//        }
        
        //위와 같은 이유로 main 스레드는 sync를 사용하지 못한다.
        //메인스레드는 계속 작업을 수행 중이기 때문에 main 스레드.sync를 하는 것은 위 queue1 deadlock과 같이 스레드 안에 같은 스레드를 sync로 사용하는 것이다.
//        DispatchQueue.main.sync {
//            print("main")
//        }
        
        //sync 사용-> 굉장히 중요한 일이라 이 작업을 끝나기 전에 다른 작업이 수행되면 안 될 때 사용한다.
        //예시. 금융권, 잔액 조회 등
    }
}

