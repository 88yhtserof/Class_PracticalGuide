//
//  InstanceDetailViewController.swift
//  PassData
//
//  Created by limyunhwi on 2021/10/03.
//

import UIKit

class InstanceDetailViewController: UIViewController {

    var mainVC: ViewController?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    //메인 뷰 컨트롤러에 있는 인스턴스에 접근해서 값 할당
    @IBAction func sendDataMainVC(_ sender: UIButton) {
        mainVC?.lbData.text = "instance 화면에서 할당된 메세지"
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
