/*
 Passing data (데이터를 넘겨주는 방법)-6가지
 1. intance property
 2. segue - 보통 Main 스토리보드에서 여러 뷰 컨트롤러가 있을 때 사용한다.
 3. instance - 해당 화면에 접근하려하는 인스턴스를 통으로 넘겨줘서 직접 접근할 수 있게 하는 방법
 4. delegate (delegation) pattern - 대인, 위임
 5. closure
 6. Notification
 */

import UIKit

class ViewController: UIViewController {

    @IBOutlet var lbData: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //2. segue
    //화면전환 시 호출된다.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //어떤 연결인지 구분해야한다. -> segue의 id로 확인
        if segue.identifier == "segueDetail" {
            //destinationd은 UIViewContriler 타입이므로 호출할 ViewController로 타입캐스팅한다.
            //만약 segue.destination이 SegueDetailViewController로 타입캐스팅이 되면 true
            if let detailVC = segue.destination as? SegueDetailViewController {
                detailVC.dataString = "메인화면에서 전달된 메세지"
            }
        }
    }
    
    ////1. instance property
    @IBAction func moveToDetail(_ sender: UIButton) {
        
        let detailVC = DetailViewController(nibName: "DetailViewController", bundle: nil)
        //인스턴스화, xib 기반으로 되어있기 때문에 nibName을 적어준다.
        
        //detailVC.someLable - 화면이 준비되지 않았는데 뷰 객체는 생성되지 않기 때문에 값을 할당할 수 없다.
        //present 다음에 작성할 수 있지만, 오류가 발생할 수 있기때문에 직접적으로 할당하지 않는다.
        //라이프 사이클을 공부하자.
        detailVC.someString = "메인 화면에서 전달된 메세지" //해당하는 인스턴스에 맞추어 프로퍼티에 접근하여 데이터를 할당
        
        self.present(detailVC, animated: true, completion: nil) //화면 이동
        
    }
    
    //3. instance
    @IBAction func moveToInstance(_ sender: UIButton) {
        let detailVC = InstanceDetailViewController(nibName: "InstanceDetailViewController", bundle: nil)
        
        detailVC.mainVC = self //나 자신을 넘겨준다. 복사가 아닌 포인터를 할당. 연결되도록.
        //나 자신에 대한 인스턴스를 넘겨준다. 나 자신에 접근할 수 있도록 한다.
        
        self.present(detailVC, animated: true, completion: nil)
    }
    
    //4. delegate pattern
    //나 자신한테 할 게 있을떄 할 수 있도록 대신 무언가를 만드는, 대리자.
    @IBAction func moveToDelegate(_ sender: UIButton) {
        let detailVC = DelegateDetailViewController(nibName: "DelegateDetailViewController", bundle: nil)
        detailVC.delegate = self
        /*나 자신, ViewController을 할당(연결), 하지만 다 넘겨주는게 아니라 해당 채택한 프로토콜 타입으로 된 내용만 넘겨준다. 연결된다. 아래 extension ViewController: DelegateDetailViewControllerDelegate 부분
        */
        
        self.present(detailVC, animated: true, completion: nil)
    }
}

//한 쪽에 몰아서 작성하여 복잡하니깐 여기에 델리게이트를 준수한다고 한다.
extension ViewController: DelegateDetailViewControllerDelegate {
    func passString(message: String) {
        self.lbData.text = message
    }
}
