//
//  SegueDetailViewController.swift
//  PassData
//
//  Created by limyunhwi on 2021/10/03.
//

import UIKit

class SegueDetailViewController: UIViewController {
    
    var dataString: String = ""
    

    @IBOutlet var lbData: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lbData.text = dataString
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
