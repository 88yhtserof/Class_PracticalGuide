//
//  DelegateDetailViewController.swift
//  PassData
//
//  Created by limyunhwi on 2021/10/03.
//

import UIKit
//델리게이트는 프로토콜을 준수하는 것들로 이루어져있다.
//weak로 하려면 AnyObject를 준수해야한다.
//인스턴스가 없어도 데이터를 전달할 수 있는 대리자를 만들기 위한 델리게이트 프로토콜
protocol DelegateDetailViewControllerDelegate: AnyObject{
    func passString(message: String)
}

class DelegateDetailViewController: UIViewController {

    //이 delegate 정의가 내려지는 곳이 따로 있기 떄문에, weak
    weak var delegate: DelegateDetailViewControllerDelegate?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func passDataToMainVC(_ sender: UIButton) {
        //메인 뷰 컨트롤러에 정의된 passString 메서드를 호출하여 메인 컨트롤러로 데이터 전달
        delegate?.passString(message: "델리게이터 화면에서 전달된 메세지")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
